# TaskFlow – Proje Tanıtım Dokümanı

## 1. Projenin Amacı
TaskFlow, bir yazılım ekibinin görevlerini, bu görevlerin sorumlularını ve durumlarını tek bir yerden takip edebilmesi için geliştirilmiş bir REST API'dir. Proje, Node.js Backend Programlama eğitiminde edinilen bilgilerin (Node.js, Express.js, routing, middleware, CRUD) uygulamalı olarak gösterilmesi amacıyla hazırlanmıştır.

## 2. Senaryo
Bir yazılım şirketi, ekip içindeki görevleri ve çalışanların sorumluluklarını takip etmek istemektedir. Sistem; görev oluşturma, çalışana atama, durum takibi ve önceliklendirme işlemlerini REST API üzerinden sunar. Bir istemci (web arayüzü, mobil uygulama veya Postman) bu API'ye HTTP istekleri göndererek görevleri yönetebilir.

## 3. Sistem Özeti

**Teknolojiler:** Node.js, Express.js, JSON dosyası ile veri saklama

**Mimari:** İstek, Logger middleware'inden geçtikten sonra Route → Controller → Model katmanlarına ilerler.

**Veri Modeli (Task):** id, title, description, status (`pending` / `in-progress` / `completed`), priority (`low` / `medium` / `high`), assignee, createdAt, updatedAt

**Endpoint'ler:**

| Method | Endpoint   | Açıklama         |
|--------|------------|------------------|
| POST   | /tasks     | Görev ekleme     |
| GET    | /tasks     | Görev listeleme  |
| GET    | /tasks/:id | Görev detayı     |
| PUT    | /tasks/:id | Görev güncelleme |
| DELETE | /tasks/:id | Görev silme      |

**Middleware:** Logger – tüm isteklerin method, endpoint ve zaman damgasını konsola ve `logs/requests.log` dosyasına kaydeder.

**HTTP Durum Kodları:** 200 (başarılı), 201 (oluşturuldu), 400 (eksik/geçersiz veri), 404 (kayıt veya endpoint bulunamadı), 500 (sunucu hatası)

## 4. Kapsam
Bu teslimde zorunlu aşamalar tamamlanmıştır: ihtiyaç analizi ve tasarım, backend altyapısı, CRUD modülü, Logger middleware ve Postman testleri. Filtreleme, validation, raporlama gibi isteğe bağlı bölümler kapsam dışıdır.
