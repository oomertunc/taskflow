const fs = require('fs');
const path = require('path');

const dataFile = path.join(__dirname, '..', '..', 'data', 'tasks.json');

function readTasks() {
  try {
    const raw = fs.readFileSync(dataFile, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    return [];
  }
}

function writeTasks(tasks) {
  fs.writeFileSync(dataFile, JSON.stringify(tasks, null, 2), 'utf-8');
}

function getAll() {
  return readTasks();
}

function getById(id) {
  return readTasks().find((t) => t.id === id);
}

function create(data) {
  const tasks = readTasks();
  const nextId = tasks.length ? Math.max(...tasks.map((t) => t.id)) + 1 : 1;
  const now = new Date().toISOString();
  const task = {
    id: nextId,
    title: data.title,
    description: data.description || '',
    status: data.status || 'pending',
    priority: data.priority || 'medium',
    assignee: data.assignee || null,
    createdAt: now,
    updatedAt: now
  };
  tasks.push(task);
  writeTasks(tasks);
  return task;
}

function update(id, data) {
  const tasks = readTasks();
  const index = tasks.findIndex((t) => t.id === id);
  if (index === -1) return null;

  const allowed = ['title', 'description', 'status', 'priority', 'assignee'];
  allowed.forEach((field) => {
    if (data[field] !== undefined) tasks[index][field] = data[field];
  });
  tasks[index].updatedAt = new Date().toISOString();

  writeTasks(tasks);
  return tasks[index];
}

function remove(id) {
  const tasks = readTasks();
  const index = tasks.findIndex((t) => t.id === id);
  if (index === -1) return null;
  const [deleted] = tasks.splice(index, 1);
  writeTasks(tasks);
  return deleted;
}

module.exports = { getAll, getById, create, update, remove };
