const express = require('express');
const logger = require('./middleware/logger');
const taskRoutes = require('./routes/taskRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// JSON body okuma
app.use(express.json());

// Temel middleware: Logger (tüm isteklerden önce çalışır)
app.use(logger);

// Ana sayfa
app.get('/', (req, res) => {
  res.json({
    message: 'TaskFlow API çalışıyor',
    endpoints: '/tasks'
  });
});

// Görev rotaları
app.use('/tasks', taskRoutes);

// Tanımsız rota -> 404
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Endpoint bulunamadı' });
});

// Genel hata yakalayıcı (ör. bozuk JSON gönderildiğinde)
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ success: false, message: 'Geçersiz JSON formatı' });
  }
  console.error(err);
  res.status(500).json({ success: false, message: 'Sunucu hatası' });
});

app.listen(PORT, () => {
  console.log(`TaskFlow API http://localhost:${PORT} adresinde çalışıyor`);
});
