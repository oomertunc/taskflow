const fs = require('fs');
const path = require('path');

const logDir = path.join(__dirname, '..', '..', 'logs');
const logFile = path.join(logDir, 'requests.log');

if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

// Her isteğin method, endpoint ve zaman damgasını konsola ve log dosyasına yazar
function logger(req, res, next) {
  const line = `[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`;
  console.log(line);
  fs.appendFile(logFile, line + '\n', (err) => {
    if (err) console.error('Log dosyasına yazılamadı:', err.message);
  });
  next();
}

module.exports = logger;
