const Task = require('../models/taskModel');

// POST /tasks - Görev ekleme
exports.createTask = (req, res) => {
  const { title } = req.body || {};
  if (!title || typeof title !== 'string' || !title.trim()) {
    return res.status(400).json({ success: false, message: 'title alanı zorunludur' });
  }
  const task = Task.create({ ...req.body, title: title.trim() });
  res.status(201).json({ success: true, message: 'Görev oluşturuldu', data: task });
};

// GET /tasks - Görev listeleme
exports.getTasks = (req, res) => {
  const tasks = Task.getAll();
  res.status(200).json({ success: true, count: tasks.length, data: tasks });
};

// GET /tasks/:id - Görev detayı
exports.getTaskById = (req, res) => {
  const task = Task.getById(Number(req.params.id));
  if (!task) {
    return res.status(404).json({ success: false, message: 'Görev bulunamadı' });
  }
  res.status(200).json({ success: true, data: task });
};

// PUT /tasks/:id - Görev güncelleme
exports.updateTask = (req, res) => {
  const task = Task.update(Number(req.params.id), req.body || {});
  if (!task) {
    return res.status(404).json({ success: false, message: 'Görev bulunamadı' });
  }
  res.status(200).json({ success: true, message: 'Görev güncellendi', data: task });
};

// DELETE /tasks/:id - Görev silme
exports.deleteTask = (req, res) => {
  const task = Task.remove(Number(req.params.id));
  if (!task) {
    return res.status(404).json({ success: false, message: 'Görev bulunamadı' });
  }
  res.status(200).json({ success: true, message: 'Görev silindi', data: task });
};
