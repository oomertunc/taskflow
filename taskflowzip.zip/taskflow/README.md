# TaskFlow – Görev ve Proje Yönetim Sistemi API

Node.js ve Express.js ile geliştirilmiş, REST API mantığında çalışan görev yönetim servisi.

## Gereksinimler
- [Node.js](https://nodejs.org) 18 veya üzeri
- npm (Node.js ile birlikte gelir)
- Postman (test için)

## Kurulum

```bash
# 1. Repoyu indirin
git clone <REPO_URL>
cd taskflow

# 2. Bağımlılıkları kurun
npm install

# 3. Sunucuyu başlatın
npm start
```

Sunucu varsayılan olarak `http://localhost:3000` adresinde çalışır. Port değiştirmek için: `PORT=4000 npm start`

Geliştirme modunda (dosya değişince otomatik yeniden başlar): `npm run dev`

## Klasör Yapısı

```
taskflow/
├── data/tasks.json              # Görev verileri (JSON dosyası)
├── docs/                        # Doküman ve Postman ekran görüntüleri
├── src/
│   ├── server.js                # Uygulama girişi
│   ├── routes/taskRoutes.js     # Route tanımları
│   ├── controllers/             # İstek işleme mantığı
│   ├── models/taskModel.js      # Veri okuma/yazma
│   └── middleware/logger.js     # Logger middleware
├── package.json
└── README.md
```

## Endpoint Listesi

| Method | Endpoint     | Açıklama        |
|--------|--------------|-----------------|
| POST   | /tasks       | Görev ekleme    |
| GET    | /tasks       | Görev listeleme |
| GET    | /tasks/:id   | Görev detayı    |
| PUT    | /tasks/:id   | Görev güncelleme|
| DELETE | /tasks/:id   | Görev silme     |

### Görev Modeli

| Alan        | Tip    | Açıklama                                        |
|-------------|--------|-------------------------------------------------|
| id          | number | Otomatik atanır                                 |
| title       | string | **Zorunlu**                                     |
| description | string | Görev açıklaması                                |
| status      | string | `pending`, `in-progress`, `completed` (varsayılan: pending) |
| priority    | string | `low`, `medium`, `high` (varsayılan: medium)    |
| assignee    | string | Görevin atandığı çalışan                        |
| createdAt   | string | Oluşturulma zamanı (otomatik)                   |
| updatedAt   | string | Son güncelleme zamanı (otomatik)                |

### Örnek İstek

`POST /tasks`
```json
{
  "title": "Rapor hazırla",
  "description": "Aylık ilerleme raporu",
  "priority": "high",
  "assignee": "musa"
}
```

Yanıt (`201 Created`):
```json
{
  "success": true,
  "message": "Görev oluşturuldu",
  "data": {
    "id": 3,
    "title": "Rapor hazırla",
    "description": "Aylık ilerleme raporu",
    "status": "pending",
    "priority": "high",
    "assignee": "musa",
    "createdAt": "2026-01-07T10:00:00.000Z",
    "updatedAt": "2026-01-07T10:00:00.000Z"
  }
}
```

## Logger

Her istek konsola ve `logs/requests.log` dosyasına şu formatta yazılır:

```
[2026-01-07T10:00:00.000Z] GET /tasks
```

## Postman ile Test

`docs/TaskFlow.postman_collection.json` dosyasını Postman'e *Import* ederek 5 CRUD isteğini hazır bulabilirsiniz. Test ekran görüntüleri `docs/screenshots/` klasöründedir.
